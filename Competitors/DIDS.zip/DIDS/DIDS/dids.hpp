#ifndef DIDS_DIDS_H
#define DIDS_DIDS_H

#include <cstdint>
#include "vector"

namespace dids {
    struct QueryStats {
        uint64_t sax_scans = 0;
        uint64_t exact_distance_computations = 0;
    };

    struct BuildStats {
        double reference_selection_seconds = 0.0;
        double grouping_seconds = 0.0;
        double structure_build_seconds = 0.0;
    };

    class DIDS {
    public:
        virtual ~DIDS() = default;

        /**
         * exact search
         * @param search_ts_vec the query ts
         * @param k the k of k-NN
         * @param approximate_search_node_num the graph nodes to search in the approximate search
         * @return the distances and positions in files of answers
         */
        virtual std::vector<std::pair<float, uint64_t>>
        search(void *search_ts_vec, uint32_t k, uint32_t approximate_search_node_num) = 0;

        /**
         * approximate search
         * @param search_ts_vec the query ts
         * @param k the k of k-NN
         * @param approximate_search_node_num the graph nodes to search in the approximate search
         * @return the distances and positions in files of answers
         */
        virtual std::vector<std::pair<float, uint64_t>>
        approximateSearch(void *search_ts_vec, uint32_t k, uint32_t approximate_search_node_num) = 0;

        virtual QueryStats lastQueryStats() const = 0;
    };
}


#endif
