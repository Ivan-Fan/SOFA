#ifndef DIDS_CONFIGURE_H
#define DIDS_CONFIGURE_H

#include <ctime>
#include <stdexcept>
#include <sys/time.h>

// Partial parallelism, incomplete
#define DIDS_PARALLELISM 1
#define DIDS_PRINT_INFO 0
#define DIDS_HDD 0


namespace dids {

// All unimportant parameters
struct Const {
    static constexpr uint32_t max_thread_num = 256;
    static uint32_t &thread_num() {
        static uint32_t value = 32;
        return value;
    }
    static constexpr uint32_t btree_max_leaf_size = 1000;
    static constexpr uint32_t btree_write_ts_batch_size = 800;
    static constexpr uint32_t btree_read_sax_batch_size = 2560;
};

inline void set_thread_num(uint32_t value) {
    if (value == 0 || value > Const::max_thread_num) {
        throw std::invalid_argument("DIDS thread count must be between 1 and 256");
    }
    Const::thread_num() = value;
}

inline uint32_t get_thread_num() {
    return Const::thread_num();
}

}  // namespace dids

#define EXACT_SEARCH_START
#define EXACT_SEARCH_END
#define APPROXIMATE_SEARCH_START
#define APPROXIMATE_SEARCH_END
#define COUNT_READ_SAX(num) read_sax_count += num;
#define COUNT_READ_TS(num) read_ts_count += num;
#define COUNT_READ_SAX_I(num, i) read_sax_count_i[i] += num;
#define COUNT_READ_TS_I(num, i) read_ts_count_i[i] += num;
#define CLEAR_INFO resetQueryStats();
#define PRINT_INFO finishQueryStats();


#endif
