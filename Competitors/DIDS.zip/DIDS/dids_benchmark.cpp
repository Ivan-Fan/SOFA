#include "DIDS/dids_factory.hpp"

#include <omp.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#ifndef DIDS_BENCHMARK_TS_LENGTH
#define DIDS_BENCHMARK_TS_LENGTH 128
#endif
#ifndef DIDS_BENCHMARK_SAX_LENGTH
#define DIDS_BENCHMARK_SAX_LENGTH 16
#endif

namespace {

using Clock = std::chrono::steady_clock;
constexpr uint32_t kDimension = DIDS_BENCHMARK_TS_LENGTH;
constexpr uint32_t kSaxLength = DIDS_BENCHMARK_SAX_LENGTH;

void print_progress(const char *phase, uint64_t completed, uint64_t total, const Clock::time_point &start);

struct Options {
    std::string mode = "all";
    std::string dataset_id;
    std::string base_file;
    std::string query_file;
    std::string index_dir;
    std::string output_dir;
    std::string scalar_type = "float32";
    std::string base_header = "raw";
    std::string query_header = "raw";
    std::string preprocessing = "none";
    std::string search_mode = "both";
    uint64_t base_count = 0;
    uint64_t query_count = 0;
    uint32_t dimension = 0;
    uint32_t threads = 1;
    uint32_t k = 1;
    uint32_t approximate_nodes = 200;
    uint32_t ref_objects = 10000;
    uint32_t leaf_size = 2000;
    uint64_t read_buffer = 100000;
    uint64_t write_buffer = 100;
    std::vector<std::string> command_line;
};

[[noreturn]] void fail(const std::string &message) {
    throw std::runtime_error(message);
}

uint64_t parse_u64(const std::string &name, const std::string &value) {
    if (value.empty() || value[0] == '-') fail(name + " must be a nonnegative integer");
    std::size_t consumed = 0;
    unsigned long long parsed = 0;
    try {
        parsed = std::stoull(value, &consumed);
    } catch (const std::exception &) {
        fail(name + " must be a nonnegative integer");
    }
    if (consumed != value.size()) fail(name + " must be a nonnegative integer");
    return static_cast<uint64_t>(parsed);
}

uint32_t parse_u32(const std::string &name, const std::string &value) {
    const uint64_t parsed = parse_u64(name, value);
    if (parsed > std::numeric_limits<uint32_t>::max()) fail(name + " is too large");
    return static_cast<uint32_t>(parsed);
}

void usage(std::ostream &out) {
    out << "Usage: dids_benchmark --mode build|query|all --dataset-id ID --dimension N\n"
        << "  --base-file PATH --base-count N --query-file PATH --query-count N\n"
        << "  --index-dir PATH --output-dir PATH [options]\n\n"
        << "Options:\n"
        << "  --scalar-type float32|uint8|int8\n"
        << "  --base-header raw|u32-count-dim\n"
        << "  --query-header raw|u32-count-dim\n"
        << "  --preprocessing none|z-normalize\n"
        << "  --search exact|approximate|both --k N --approximate-nodes N\n"
        << "  --threads N --ref-objects N --leaf-size N\n"
        << "  --read-buffer N --write-buffer N\n";
}

Options parse_options(int argc, char **argv) {
    Options o;
    for (int i = 0; i < argc; ++i) o.command_line.emplace_back(argv[i]);
    std::map<std::string, std::string *> strings = {
        {"--mode", &o.mode}, {"--dataset-id", &o.dataset_id},
        {"--base-file", &o.base_file}, {"--query-file", &o.query_file},
        {"--index-dir", &o.index_dir}, {"--output-dir", &o.output_dir},
        {"--scalar-type", &o.scalar_type}, {"--base-header", &o.base_header},
        {"--query-header", &o.query_header}, {"--preprocessing", &o.preprocessing},
        {"--search", &o.search_mode}
    };
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "-h" || arg == "--help") {
            usage(std::cout);
            std::exit(0);
        }
        if (i + 1 >= argc) fail("missing value for " + arg);
        const std::string value = argv[++i];
        auto string_it = strings.find(arg);
        if (string_it != strings.end()) {
            *string_it->second = value;
        } else if (arg == "--base-count") o.base_count = parse_u64(arg, value);
        else if (arg == "--query-count") o.query_count = parse_u64(arg, value);
        else if (arg == "--dimension") o.dimension = parse_u32(arg, value);
        else if (arg == "--threads") o.threads = parse_u32(arg, value);
        else if (arg == "--k") o.k = parse_u32(arg, value);
        else if (arg == "--approximate-nodes") o.approximate_nodes = parse_u32(arg, value);
        else if (arg == "--ref-objects") o.ref_objects = parse_u32(arg, value);
        else if (arg == "--leaf-size") o.leaf_size = parse_u32(arg, value);
        else if (arg == "--read-buffer") o.read_buffer = parse_u64(arg, value);
        else if (arg == "--write-buffer") o.write_buffer = parse_u64(arg, value);
        else fail("unknown option: " + arg);
    }
    return o;
}

bool in(const std::string &value, std::initializer_list<const char *> allowed) {
    for (const char *candidate : allowed) if (value == candidate) return true;
    return false;
}

bool wants_build(const Options &o) { return o.mode == "build" || o.mode == "all"; }
bool wants_query(const Options &o) { return o.mode == "query" || o.mode == "all"; }

void validate(const Options &o) {
    if (!in(o.mode, {"build", "query", "all"})) fail("--mode must be build, query, or all");
    if (o.dataset_id.empty()) fail("--dataset-id is required");
    if (o.index_dir.empty()) fail("--index-dir is required");
    if (o.output_dir.empty()) fail("--output-dir is required");
    if (o.dimension != kDimension) {
        fail("this binary was compiled for dimension " + std::to_string(kDimension) +
             ", but --dimension is " + std::to_string(o.dimension));
    }
    // Upstream PAA uses floor(dimension / SAX length) samples per segment.
    // Non-divisible layouts (SPACEV: 100/34) omit trailing coordinates from
    // the lower bound, while exact distance still uses the full vector.
    if (kSaxLength == 0 || kSaxLength > kDimension)
        fail("compiled SAX length must be between 1 and the dimension");
    if (!in(o.scalar_type, {"float32", "uint8", "int8"})) fail("unsupported --scalar-type");
    if (!in(o.base_header, {"raw", "u32-count-dim"}) ||
        !in(o.query_header, {"raw", "u32-count-dim"})) fail("unsupported header format");
    if (!in(o.preprocessing, {"none", "z-normalize"})) fail("unsupported --preprocessing");
    if (!in(o.search_mode, {"exact", "approximate", "both"})) fail("unsupported --search mode");
    if (o.threads == 0 || o.threads > dids::Const::max_thread_num) fail("--threads must be 1..256");
    if (o.k == 0 || o.approximate_nodes == 0 || o.ref_objects == 0 || o.leaf_size == 0 ||
        o.read_buffer == 0 || o.write_buffer == 0) fail("numeric tuning parameters must be positive");
    if (wants_build(o)) {
        if (o.base_file.empty() || o.base_count == 0) fail("build mode requires --base-file and --base-count");
        if (o.base_count / 100 < o.ref_objects) {
            fail("DIDS samples every 100th base row; --ref-objects must not exceed --base-count / 100");
        }
        if (o.ref_objects < o.threads) fail("--ref-objects must be at least --threads for exact parallel search");
    }
    if (wants_query(o)) {
        if (o.query_file.empty() || o.query_count == 0) fail("query mode requires --query-file and --query-count");
        if (o.k > o.base_count && o.base_count != 0) fail("--k cannot exceed --base-count");
    }
}

void make_dirs(const std::string &path) {
    if (path.empty()) fail("empty directory path");
    std::string current;
    if (path[0] == '/') current = "/";
    std::stringstream stream(path);
    std::string part;
    while (std::getline(stream, part, '/')) {
        if (part.empty()) continue;
        if (!current.empty() && current.back() != '/') current += '/';
        current += part;
        if (::mkdir(current.c_str(), 0755) != 0 && errno != EEXIST) {
            fail("cannot create directory " + current + ": " + std::strerror(errno));
        }
    }
}

uint64_t file_size(const std::string &path) {
    struct stat info {};
    if (::stat(path.c_str(), &info) != 0) fail("cannot stat " + path + ": " + std::strerror(errno));
    if (!S_ISREG(info.st_mode)) fail("not a regular file: " + path);
    return static_cast<uint64_t>(info.st_size);
}

uint64_t scalar_size(const std::string &type) { return type == "float32" ? 4 : 1; }

uint64_t data_offset_and_validate(const std::string &path, const std::string &header,
                                  const std::string &type, uint64_t count, uint32_t dimension) {
    uint64_t offset = 0;
    if (header == "u32-count-dim") {
        std::ifstream input(path, std::ios::binary);
        uint32_t stored_count = 0, stored_dimension = 0;
        input.read(reinterpret_cast<char *>(&stored_count), sizeof(stored_count));
        input.read(reinterpret_cast<char *>(&stored_dimension), sizeof(stored_dimension));
        if (!input) fail("cannot read vector header from " + path);
        if (stored_count < count) fail("header count in " + path + " is smaller than requested count");
        if (stored_dimension != dimension) fail("header dimension mismatch in " + path);
        offset = 8;
    }
    const uint64_t row_bytes = scalar_size(type) * dimension;
    if (count > (std::numeric_limits<uint64_t>::max() - offset) / row_bytes) fail("requested file extent overflows");
    const uint64_t required = offset + count * row_bytes;
    const uint64_t actual = file_size(path);
    if (actual < required) {
        fail(path + " is too small: needs at least " + std::to_string(required) +
             " bytes, has " + std::to_string(actual));
    }
    return offset;
}

void normalize(float *row) {
    double sum = 0.0;
    for (uint32_t i = 0; i < kDimension; ++i) sum += row[i];
    const double mean = sum / kDimension;
    double squared = 0.0;
    for (uint32_t i = 0; i < kDimension; ++i) {
        const double centered = row[i] - mean;
        squared += centered * centered;
    }
    const double deviation = std::sqrt(squared / kDimension);
    if (deviation == 0.0) {
        std::fill(row, row + kDimension, 0.0f);
    } else {
        for (uint32_t i = 0; i < kDimension; ++i) row[i] = static_cast<float>((row[i] - mean) / deviation);
    }
}

void read_row(std::istream &input, const std::string &type, float *row,
              std::vector<unsigned char> &bytes) {
    if (type == "float32") {
        input.read(reinterpret_cast<char *>(row), sizeof(float) * kDimension);
    } else {
        input.read(reinterpret_cast<char *>(bytes.data()), kDimension);
        if (type == "uint8") {
            for (uint32_t i = 0; i < kDimension; ++i) row[i] = static_cast<float>(bytes[i]);
        } else {
            for (uint32_t i = 0; i < kDimension; ++i) {
                const int8_t value = static_cast<int8_t>(bytes[i]);
                row[i] = static_cast<float>(value);
            }
        }
    }
    if (!input) fail("short read while decoding input rows");
}

std::string prepare_base(const Options &o) {
    const uint64_t offset = data_offset_and_validate(o.base_file, o.base_header, o.scalar_type,
                                                     o.base_count, o.dimension);
    if (o.scalar_type == "float32" && o.preprocessing == "none" && offset == 0) {
        std::cerr << ">> preparation: using raw float32 base file directly\n";
        return o.base_file;
    }
    const std::string prepared = o.index_dir + "/prepared_base.f32";
    std::cerr << ">> preparation: converting " << o.base_count << " rows from "
              << o.scalar_type << " to float32";
    if (o.preprocessing == "z-normalize") std::cerr << " with per-row z-normalization";
    std::cerr << "\n>> preparation output: " << prepared << '\n';
    std::ifstream input(o.base_file, std::ios::binary);
    std::ofstream output(prepared, std::ios::binary | std::ios::trunc);
    if (!input || !output) fail("cannot open prepared-base input or output");
    input.seekg(static_cast<std::streamoff>(offset));
    std::vector<float> row(kDimension);
    std::vector<unsigned char> bytes(kDimension);
    const uint64_t report_interval = std::max<uint64_t>(1, o.base_count / 100);
    const auto progress_start = Clock::now();
    for (uint64_t i = 0; i < o.base_count; ++i) {
        read_row(input, o.scalar_type, row.data(), bytes);
        if (o.preprocessing == "z-normalize") normalize(row.data());
        output.write(reinterpret_cast<const char *>(row.data()), sizeof(float) * kDimension);
        if (!output) fail("failed writing " + prepared);
        if ((i + 1) % report_interval == 0 || i + 1 == o.base_count) {
            print_progress("preparation", i + 1, o.base_count, progress_start);
        }
    }
    std::cerr << "\n>> preparation finished\n";
    return prepared;
}

std::vector<std::vector<float>> load_queries(const Options &o) {
    const uint64_t offset = data_offset_and_validate(o.query_file, o.query_header, o.scalar_type,
                                                     o.query_count, o.dimension);
    std::ifstream input(o.query_file, std::ios::binary);
    if (!input) fail("cannot open query file " + o.query_file);
    input.seekg(static_cast<std::streamoff>(offset));
    std::vector<std::vector<float>> queries(o.query_count, std::vector<float>(kDimension));
    std::vector<unsigned char> bytes(kDimension);
    for (uint64_t i = 0; i < o.query_count; ++i) {
        read_row(input, o.scalar_type, queries[i].data(), bytes);
        if (o.preprocessing == "z-normalize") normalize(queries[i].data());
    }
    return queries;
}

std::string with_slash(std::string path) {
    if (path.empty() || path.back() != '/') path += '/';
    return path;
}

std::string json_escape(const std::string &value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20) out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << int(c);
                else out << c;
        }
    }
    return out.str();
}

std::string utc_timestamp() {
    const std::time_t now = std::time(nullptr);
    std::tm value {};
#ifdef _WIN32
    gmtime_s(&value, &now);
#else
    gmtime_r(&now, &value);
#endif
    char buffer[32];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &value);
    return buffer;
}

void write_manifest(const Options &o, const std::string &path) {
    std::ofstream out(path, std::ios::trunc);
    if (!out) fail("cannot write " + path);
    out << "{\n"
        << "  \"competitor\": \"dids\",\n"
        << "  \"dataset_id\": \"" << json_escape(o.dataset_id) << "\",\n"
        << "  \"dimension\": " << o.dimension << ",\n"
        << "  \"sax_length\": " << kSaxLength << ",\n"
        << "  \"base_count\": " << o.base_count << ",\n"
        << "  \"query_count\": " << o.query_count << ",\n"
        << "  \"scalar_type\": \"" << o.scalar_type << "\",\n"
        << "  \"base_header\": \"" << o.base_header << "\",\n"
        << "  \"query_header\": \"" << o.query_header << "\",\n"
        << "  \"preprocessing\": \"" << o.preprocessing << "\",\n"
        << "  \"metric\": \"squared_l2\",\n"
        << "  \"timestamp_utc\": \"" << utc_timestamp() << "\",\n"
        << "  \"compiler\": \"" << json_escape(__VERSION__) << "\",\n"
        << "  \"threads\": " << o.threads << ",\n"
        << "  \"k\": " << o.k << ",\n"
        << "  \"approximate_nodes\": " << o.approximate_nodes << ",\n"
        << "  \"base_file\": \"" << json_escape(o.base_file) << "\",\n"
        << "  \"query_file\": \"" << json_escape(o.query_file) << "\",\n"
        << "  \"index_dir\": \"" << json_escape(o.index_dir) << "\",\n"
        << "  \"command\": [";
    for (std::size_t i = 0; i < o.command_line.size(); ++i) {
        if (i) out << ", ";
        out << "\"" << json_escape(o.command_line[i]) << "\"";
    }
    out << "]\n}\n";
}

long max_rss_kib() {
    struct rusage usage {};
    if (getrusage(RUSAGE_SELF, &usage) != 0) return -1;
#ifdef __APPLE__
    return usage.ru_maxrss / 1024;
#else
    return usage.ru_maxrss;
#endif
}

double seconds_since(const Clock::time_point &start) {
    return std::chrono::duration<double>(Clock::now() - start).count();
}

std::string format_duration(double seconds) {
    const auto total = static_cast<uint64_t>(std::max(0.0, seconds));
    std::ostringstream out;
    out << std::setfill('0') << std::setw(2) << total / 3600 << ':'
        << std::setw(2) << (total / 60) % 60 << ':' << std::setw(2) << total % 60;
    return out.str();
}

void print_progress(const char *phase, uint64_t completed, uint64_t total, const Clock::time_point &start) {
    const double elapsed = seconds_since(start);
    const double percent = 100.0 * static_cast<double>(completed) / total;
    const double remaining = completed == total ? 0.0 : elapsed * (total - completed) / completed;
    std::cerr << "\r>> " << phase << ": " << std::fixed << std::setprecision(1) << percent
              << "% | elapsed " << format_duration(elapsed) << " | ETA " << format_duration(remaining) << std::flush;
}

double recall_at_k(const std::vector<std::pair<float, uint64_t>> &exact,
                   const std::vector<std::pair<float, uint64_t>> &approximate) {
    std::set<uint64_t> exact_positions;
    for (const auto &item : exact) exact_positions.insert(item.second);
    uint64_t matches = 0;
    for (const auto &item : approximate) if (exact_positions.count(item.second)) ++matches;
    return exact.empty() ? 0.0 : static_cast<double>(matches) / exact.size();
}

void append_results(std::ofstream &csv, uint64_t query_id, const std::string &mode,
                    const std::vector<std::pair<float, uint64_t>> &results,
                    double elapsed_ms, const dids::QueryStats &stats, double recall) {
    for (std::size_t rank = 0; rank < results.size(); ++rank) {
        csv << query_id << ',' << mode << ',' << (rank + 1) << ','
            << std::setprecision(9) << results[rank].first << ',' << results[rank].second << ','
            << std::setprecision(9) << elapsed_ms << ','
            << stats.sax_scans << ',' << stats.exact_distance_computations << ',';
        if (std::isnan(recall)) csv << "";
        else csv << std::setprecision(6) << recall;
        csv << '\n';
    }
}

int run(const Options &o) {
    make_dirs(o.index_dir);
    make_dirs(o.output_dir);
    dids::set_thread_num(o.threads);
    omp_set_dynamic(0);
    omp_set_num_threads(static_cast<int>(o.threads));
    const std::string index_dir = with_slash(o.index_dir);

    if (wants_build(o)) {
        std::cerr << ">> phase: prepare base data\n";
        const auto preparation_start = Clock::now();
        const std::string prepared_base = prepare_base(o);
        const double preparation_seconds = seconds_since(preparation_start);
        std::cerr << ">> phase: build DIDS index\n";
        const auto build_start = Clock::now();
        const dids::BuildStats dids_build_stats = dids::DIDSFactory<kDimension, kSaxLength>::create(
            o.base_count, o.ref_objects, o.leaf_size, o.read_buffer, o.write_buffer,
            o.dataset_id, prepared_base, index_dir);
        const double build_seconds = seconds_since(build_start);
        std::cerr << ">> index build time breakdown\n"
                  << "   base preparation: " << std::fixed << std::setprecision(3) << preparation_seconds << " s\n"
                  << "   reference selection: " << dids_build_stats.reference_selection_seconds << " s\n"
                  << "   grouping: " << dids_build_stats.grouping_seconds << " s\n"
                  << "   B-trees and graph: " << dids_build_stats.structure_build_seconds << " s\n"
                  << "   total DIDS build: " << build_seconds << " s\n";
        std::ofstream build_csv(o.output_dir + "/build.csv", std::ios::trunc);
        if (!build_csv) fail("cannot write build.csv");
        build_csv << "dataset_id,base_count,dimension,threads,preparation_seconds,reference_selection_seconds,grouping_seconds,structure_build_seconds,index_build_seconds,max_rss_kib,base_loading_included,source_conversion_included\n"
                  << o.dataset_id << ',' << o.base_count << ',' << o.dimension << ',' << o.threads << ','
                  << std::setprecision(9) << preparation_seconds << ','
                  << dids_build_stats.reference_selection_seconds << ',' << dids_build_stats.grouping_seconds << ','
                  << dids_build_stats.structure_build_seconds << ',' << build_seconds << ',' << max_rss_kib()
                  << ",true,false\n";
        write_manifest(o, o.index_dir + "/benchmark_metadata.json");
    }

    if (wants_query(o)) {
        std::cerr << ">> phase: load " << o.query_count << " queries\n";
        const auto queries = load_queries(o);
        std::cerr << ">> phase: load DIDS index\n";
        std::unique_ptr<dids::DIDS> index(
            dids::DIDSFactory<kDimension, kSaxLength>::createFromIndex(o.dataset_id, index_dir));
        std::ofstream csv(o.output_dir + "/queries.csv", std::ios::trunc);
        if (!csv) fail("cannot write queries.csv");
        csv << "query_id,mode,rank,squared_l2,index_position,query_time_ms,sax_scans,exact_distance_computations,recall_at_k\n";
        std::cerr << ">> phase: execute " << o.search_mode << " queries\n";
        const auto query_progress_start = Clock::now();
        for (uint64_t i = 0; i < queries.size(); ++i) {
            std::vector<std::pair<float, uint64_t>> exact;
            std::vector<std::pair<float, uint64_t>> approximate;
            double exact_ms = 0.0, approximate_ms = 0.0;
            dids::QueryStats exact_stats, approximate_stats;
            if (o.search_mode == "exact" || o.search_mode == "both") {
                const auto start = Clock::now();
                exact = index->search(const_cast<float *>(queries[i].data()), o.k, o.approximate_nodes);
                exact_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
                exact_stats = index->lastQueryStats();
            }
            if (o.search_mode == "approximate" || o.search_mode == "both") {
                const auto start = Clock::now();
                approximate = index->approximateSearch(const_cast<float *>(queries[i].data()), o.k, o.approximate_nodes);
                approximate_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
                approximate_stats = index->lastQueryStats();
            }
            const double recall = o.search_mode == "both" ? recall_at_k(exact, approximate) : std::numeric_limits<double>::quiet_NaN();
            if (!exact.empty()) append_results(csv, i, "exact", exact, exact_ms, exact_stats, std::numeric_limits<double>::quiet_NaN());
            if (!approximate.empty()) append_results(csv, i, "approximate", approximate, approximate_ms, approximate_stats, recall);
            print_progress("queries", i + 1, queries.size(), query_progress_start);
        }
        std::cerr << "\n>> queries finished\n";
    }
    write_manifest(o, o.output_dir + "/manifest.json");
    return 0;
}

}  // namespace

int main(int argc, char **argv) {
    try {
        const Options options = parse_options(argc, argv);
        validate(options);
        return run(options);
    } catch (const std::exception &error) {
        std::cerr << "dids_benchmark: " << error.what() << '\n';
        return 2;
    }
}
