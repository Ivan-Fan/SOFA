#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
REPO_ROOT=$(cd -- "$SCRIPT_DIR/.." && pwd -P)
# shellcheck source=lib/datasets.sh
source "$SCRIPT_DIR/lib/datasets.sh"

usage() {
    cat <<'USAGE'
Usage: run_dids.sh DATASET --threads N [options]

Core options:
  --mode all|build|query        Build and query by default
  --data-root PATH              Main datasets (default: $DIDS_DATA_ROOT or MESSI root)
  --query-root PATH             Main queries (default: data root)
  --seisbench-root PATH         SeisBench datasets
  --seisbench-query-root PATH   SeisBench queries
  --base-file PATH              Override registered base file
  --query-file PATH             Override registered query file
  --base-count N                Override registered row count
  --query-count N               Query rows (default: 100)
  --dimension N                 Override registered dimension
  --scalar-type TYPE            float32, uint8, or int8
  --preprocessing MODE          none or z-normalize
  --base-header FORMAT          raw or u32-count-dim
  --query-header FORMAT         raw or u32-count-dim

DIDS options:
  --sax-length N                Override the registered SAX segment count
  --search MODE                 exact, approximate, or both (default: both)
  --k N                         Neighbors (default: 1)
  --approximate-nodes N         Graph leaves to seed (default: 200)
  --ref-objects N               Reference objects (default: 10000 for 100M rows;
                                smaller datasets fall back to floor(sqrt(rows)))
  --leaf-size N                 Approximate leaf size (default: 2000)
  --read-buffer N               Build read buffer in rows (default: 100000)
  --write-buffer N              Per-reference write buffer in rows (default: 100)

Infrastructure options:
  --binary PATH                 Dimension-and-SAX-specific executable
  --index-root PATH             Persist the index at PATH instead of using /tmp
  --temporary-index             Use a disposable /tmp index (the default without an index root)
  --output-root PATH            Default: $DIDS_RESULTS_ROOT or $HOME/dids_results
  --numa auto|none|N            NUMA interleave policy (default: auto)
  --force                       Allow replacing CSV/manifest files for this run
  --dry-run                     Print the resolved command only
USAGE
}

die() { printf 'Error: %s\n' "$*" >&2; exit 2; }
is_positive_integer() { [[ $1 =~ ^[1-9][0-9]*$ ]]; }
integer_sqrt() {
    local number=$1 estimate next
    if (( number < 2 )); then
        printf '%s\n' "$number"
        return
    fi
    estimate=$number
    next=$(((estimate + number / estimate) / 2))
    while (( next < estimate )); do
        estimate=$next
        next=$(((estimate + number / estimate) / 2))
    done
    printf '%s\n' "$estimate"
}
resolve_path() { if [[ $2 == /* ]]; then printf '%s\n' "$2"; else printf '%s/%s\n' "${1%/}" "$2"; fi; }
print_command() { printf '%q ' "$@"; printf '\n'; }

print_benchmark_summary() {
    local fields header expected_header
    expected_header='query_id,mode,rank,squared_l2,index_position,query_time_ms,sax_scans,exact_distance_computations,recall_at_k'
    IFS= read -r header < "$OUTPUT_DIR/queries.csv" || {
        printf 'Warning: queries.csv is missing; no DIDS summary was produced.\n' >&2
        return 0
    }
    if [[ $header != "$expected_header" ]]; then
        printf 'Warning: queries.csv was written by an older benchmark binary; rebuild DIDS before using the summary.\n' >&2
        return 0
    fi

    fields=$(awk -F, -v base_count="$DATASET_SIZE" -v leaf_size="$LEAF_SIZE" -v graph_nodes="$APPROXIMATE_NODES" '
        function format_count(value) {
            if (value >= 1000000) return sprintf("%.2f M/query", value / 1000000)
            if (value >= 1000) return sprintf("%.2f K/query", value / 1000)
            return sprintf("%.2f/query", value)
        }
        $1 == "query_id" { next }
        $2 == "exact" && $3 == 1 {
            queries++
            wall_ms += $6
            sax_scans += $7
            exact_computations += $8
        }
        END {
            if (!queries) exit 1
            avg_sax = sax_scans / queries
            avg_exact = exact_computations / queries
            printf "DIDS\texact\tSAX\t%s\t%s\t%s\t%.2f%%\t%s\t%.2f%%\t%.3f s\n", \
                leaf_size, graph_nodes, format_count(avg_sax), 100 * avg_sax / base_count, \
                format_count(avg_exact), 100 * avg_exact / base_count, wall_ms / queries / 1000
        }
    ' "$OUTPUT_DIR/queries.csv") || {
        printf 'Warning: could not parse query statistics for the DIDS summary.\n' >&2
        return 0
    }

    printf '\n=== Benchmark summary: dataset=%s, profile=standard ===\n' "$DATASET_ID"
    printf '%-6s  %-8s  %-7s  %8s  %11s  %18s  %8s  %18s  %8s  %11s\n' \
        Layout Method Binning 'Leaf cap.' 'Graph nodes' 'SAX scans/query' 'SAX %' 'Exact comps/query' 'Exact %' 'Mean/query'
    printf '%s\n' '-------------------------------------------------------------------------------------------------------------------------------'
    IFS=$'\t' read -r layout method binning leaf_cap graph_nodes sax_scans sax_pct exact exact_pct wall <<< "$fields"
    printf '%-6s  %-8s  %-7s  %8s  %11s  %18s  %8s  %18s  %8s  %11s\n' \
        "$layout" "$method" "$binning" "$leaf_cap" "$graph_nodes" "$sax_scans" "$sax_pct" "$exact" "$exact_pct" "$wall"
}

[[ $# -ge 1 ]] || { usage >&2; exit 2; }
if [[ $1 == -h || $1 == --help ]]; then
    usage
    exit 0
fi
DATASET=$1
shift

MODE=all
THREADS=
DATA_ROOT=${DIDS_DATA_ROOT:-${MESSI_DATA_ROOT:-/home/tmp/schaefpa/messi_datasets}}
QUERY_ROOT=${DIDS_QUERY_ROOT:-}
SEISBENCH_ROOT=${DIDS_SEISBENCH_ROOT:-${MESSI_SEISBENCH_ROOT:-/home/tmp/schaefpa/seismic}}
SEISBENCH_QUERY_ROOT=${DIDS_SEISBENCH_QUERY_ROOT:-}
BASE_OVERRIDE=
QUERY_OVERRIDE=
BASE_COUNT_OVERRIDE=
QUERY_COUNT=100
DIMENSION_OVERRIDE=
SAX_LENGTH_OVERRIDE=
SCALAR_OVERRIDE=
PREPROCESS_OVERRIDE=
BASE_HEADER_OVERRIDE=
QUERY_HEADER_OVERRIDE=
SEARCH=both
K=1
APPROXIMATE_NODES=200
REF_OBJECTS=
REF_OBJECTS_REQUESTED=false
LEAF_SIZE=2000
READ_BUFFER=100000
WRITE_BUFFER=100
BINARY=
INDEX_ROOT=${DIDS_INDEX_ROOT:-"$HOME/dids_indexes"}
OUTPUT_ROOT=${DIDS_RESULTS_ROOT:-"$HOME/dids_results"}
TEMPORARY_INDEX=true
TEMPORARY_INDEX_ROOT=
INDEX_ROOT_REQUESTED=false
TEMPORARY_INDEX_REQUESTED=false
NUMA_MODE=auto
FORCE=false
DRY_RUN=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode) [[ $# -ge 2 ]] || die "$1 requires a value"; MODE=$2; shift 2 ;;
        --threads) [[ $# -ge 2 ]] || die "$1 requires a value"; THREADS=$2; shift 2 ;;
        --data-root) [[ $# -ge 2 ]] || die "$1 requires a value"; DATA_ROOT=$2; shift 2 ;;
        --query-root) [[ $# -ge 2 ]] || die "$1 requires a value"; QUERY_ROOT=$2; shift 2 ;;
        --seisbench-root) [[ $# -ge 2 ]] || die "$1 requires a value"; SEISBENCH_ROOT=$2; shift 2 ;;
        --seisbench-query-root) [[ $# -ge 2 ]] || die "$1 requires a value"; SEISBENCH_QUERY_ROOT=$2; shift 2 ;;
        --base-file) [[ $# -ge 2 ]] || die "$1 requires a value"; BASE_OVERRIDE=$2; shift 2 ;;
        --query-file) [[ $# -ge 2 ]] || die "$1 requires a value"; QUERY_OVERRIDE=$2; shift 2 ;;
        --base-count) [[ $# -ge 2 ]] || die "$1 requires a value"; BASE_COUNT_OVERRIDE=$2; shift 2 ;;
        --query-count) [[ $# -ge 2 ]] || die "$1 requires a value"; QUERY_COUNT=$2; shift 2 ;;
        --dimension) [[ $# -ge 2 ]] || die "$1 requires a value"; DIMENSION_OVERRIDE=$2; shift 2 ;;
        --sax-length) [[ $# -ge 2 ]] || die "$1 requires a value"; SAX_LENGTH_OVERRIDE=$2; shift 2 ;;
        --scalar-type) [[ $# -ge 2 ]] || die "$1 requires a value"; SCALAR_OVERRIDE=$2; shift 2 ;;
        --preprocessing) [[ $# -ge 2 ]] || die "$1 requires a value"; PREPROCESS_OVERRIDE=$2; shift 2 ;;
        --base-header) [[ $# -ge 2 ]] || die "$1 requires a value"; BASE_HEADER_OVERRIDE=$2; shift 2 ;;
        --query-header) [[ $# -ge 2 ]] || die "$1 requires a value"; QUERY_HEADER_OVERRIDE=$2; shift 2 ;;
        --search) [[ $# -ge 2 ]] || die "$1 requires a value"; SEARCH=$2; shift 2 ;;
        --k) [[ $# -ge 2 ]] || die "$1 requires a value"; K=$2; shift 2 ;;
        --approximate-nodes) [[ $# -ge 2 ]] || die "$1 requires a value"; APPROXIMATE_NODES=$2; shift 2 ;;
        --ref-objects) [[ $# -ge 2 ]] || die "$1 requires a value"; REF_OBJECTS=$2; REF_OBJECTS_REQUESTED=true; shift 2 ;;
        --leaf-size) [[ $# -ge 2 ]] || die "$1 requires a value"; LEAF_SIZE=$2; shift 2 ;;
        --read-buffer) [[ $# -ge 2 ]] || die "$1 requires a value"; READ_BUFFER=$2; shift 2 ;;
        --write-buffer) [[ $# -ge 2 ]] || die "$1 requires a value"; WRITE_BUFFER=$2; shift 2 ;;
        --binary) [[ $# -ge 2 ]] || die "$1 requires a value"; BINARY=$2; shift 2 ;;
        --index-root) [[ $# -ge 2 ]] || die "$1 requires a value"; INDEX_ROOT=$2; INDEX_ROOT_REQUESTED=true; shift 2 ;;
        --temporary-index) TEMPORARY_INDEX_REQUESTED=true; shift ;;
        --output-root) [[ $# -ge 2 ]] || die "$1 requires a value"; OUTPUT_ROOT=$2; shift 2 ;;
        --numa) [[ $# -ge 2 ]] || die "$1 requires a value"; NUMA_MODE=$2; shift 2 ;;
        --force) FORCE=true; shift ;;
        --dry-run) DRY_RUN=true; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown option '$1'" ;;
    esac
done

if [[ -n ${DIDS_INDEX_ROOT:-} || $INDEX_ROOT_REQUESTED == true ]]; then
    TEMPORARY_INDEX=false
fi
if [[ $TEMPORARY_INDEX_REQUESTED == true ]]; then
    [[ $INDEX_ROOT_REQUESTED == false ]] || die '--temporary-index cannot be combined with --index-root'
    TEMPORARY_INDEX=true
fi

load_dataset "$DATASET" standard
[[ -n ${DIDS_SAX_LENGTH:-} ]] || die "scripts/lib/datasets.sh did not define DIDS_SAX_LENGTH for '$DATASET'; copy the current DIDS scripts/lib/datasets.sh together with run_dids.sh (do not use the scripts_bak registry)"
[[ -n $BASE_OVERRIDE ]] && DATASET_FILE=$BASE_OVERRIDE
[[ -n $QUERY_OVERRIDE ]] && QUERY_FILE=$QUERY_OVERRIDE
[[ -n $BASE_COUNT_OVERRIDE ]] && DATASET_SIZE=$BASE_COUNT_OVERRIDE
[[ -n $DIMENSION_OVERRIDE ]] && TS_SIZE=$DIMENSION_OVERRIDE
[[ -n $SAX_LENGTH_OVERRIDE ]] && DIDS_SAX_LENGTH=$SAX_LENGTH_OVERRIDE
[[ -n $SCALAR_OVERRIDE ]] && SCALAR_TYPE=$SCALAR_OVERRIDE
[[ -n $PREPROCESS_OVERRIDE ]] && PREPROCESSING=$PREPROCESS_OVERRIDE
[[ -n $BASE_HEADER_OVERRIDE ]] && BASE_HEADER=$BASE_HEADER_OVERRIDE
[[ -n $QUERY_HEADER_OVERRIDE ]] && QUERY_HEADER=$QUERY_HEADER_OVERRIDE

[[ -n $THREADS ]] || die '--threads is required'
is_positive_integer "$THREADS" || die "expected a positive integer, got '$THREADS'"
is_positive_integer "$DATASET_SIZE" || die "expected a positive integer, got '$DATASET_SIZE'"
SAMPLE_COUNT=$((DATASET_SIZE / 100))
if [[ $REF_OBJECTS_REQUESTED == false ]]; then
    REF_OBJECTS=10000
    if (( REF_OBJECTS > SAMPLE_COUNT )); then
        REF_OBJECTS=$(integer_sqrt "$DATASET_SIZE")
        if (( REF_OBJECTS < THREADS )); then
            REF_OBJECTS=$THREADS
        fi
        printf 'Using %s reference objects for %s rows (paper guideline: n_r ~= sqrt(n)).\n' \
            "$REF_OBJECTS" "$DATASET_SIZE" >&2
    fi
fi
for value in "$THREADS" "$DATASET_SIZE" "$QUERY_COUNT" "$TS_SIZE" "$DIDS_SAX_LENGTH" "$K" "$APPROXIMATE_NODES" "$REF_OBJECTS" "$LEAF_SIZE" "$READ_BUFFER" "$WRITE_BUFFER"; do
    is_positive_integer "$value" || die "expected a positive integer, got '$value'"
done
(( DIDS_SAX_LENGTH <= TS_SIZE )) || die "--sax-length must not exceed the dimension ($TS_SIZE)"
[[ $MODE == all || $MODE == build || $MODE == query ]] || die '--mode must be all, build, or query'
[[ $NUMA_MODE == auto || $NUMA_MODE == none || $NUMA_MODE =~ ^[1-9][0-9]*$ ]] || die '--numa must be auto, none, or a positive integer'
[[ $TEMPORARY_INDEX == false || $MODE == all ]] || die '--temporary-index requires --mode all'
(( REF_OBJECTS <= SAMPLE_COUNT )) || die "--ref-objects must not exceed the 1% clustering sample ($SAMPLE_COUNT for $DATASET_SIZE rows)"
(( REF_OBJECTS >= THREADS )) || die '--ref-objects must be at least --threads for exact parallel search'

cleanup_temporary_index() {
    local status=$?
    trap - EXIT
    if [[ -n $TEMPORARY_INDEX_ROOT && -d $TEMPORARY_INDEX_ROOT && $TEMPORARY_INDEX_ROOT == /tmp/dids-index.* ]]; then
        rm -rf -- "$TEMPORARY_INDEX_ROOT" || printf 'Warning: could not remove temporary index directory: %s\n' "$TEMPORARY_INDEX_ROOT" >&2
    fi
    exit "$status"
}

if [[ $TEMPORARY_INDEX == true ]]; then
    if [[ $DRY_RUN == true ]]; then
        INDEX_ROOT=/tmp/dids-index.DRY-RUN
    else
        TEMPORARY_INDEX_ROOT=$(mktemp -d /tmp/dids-index.XXXXXX) || die 'could not create a temporary index directory under /tmp'
        INDEX_ROOT=$TEMPORARY_INDEX_ROOT
        trap cleanup_temporary_index EXIT
    fi
fi

if [[ $DATASET_ROOT_KIND == seisbench ]]; then
    BASE_ROOT=$SEISBENCH_ROOT
    QUERY_BASE_ROOT=${SEISBENCH_QUERY_ROOT:-$SEISBENCH_ROOT}
else
    BASE_ROOT=$DATA_ROOT
    QUERY_BASE_ROOT=${QUERY_ROOT:-$DATA_ROOT}
fi
BASE_PATH=$(resolve_path "$BASE_ROOT" "$DATASET_FILE")
QUERY_PATH=$(resolve_path "$QUERY_BASE_ROOT" "$QUERY_FILE")
BINARY=${BINARY:-"$REPO_ROOT/bin/dids_benchmark_${TS_SIZE}_sax${DIDS_SAX_LENGTH}"}
SAX_LENGTH=$DIDS_SAX_LENGTH
INDEX_DIR=$INDEX_ROOT/$DATASET_ID/dim-$TS_SIZE-sax-$SAX_LENGTH/ref-$REF_OBJECTS-leaf-$LEAF_SIZE
OUTPUT_DIR=$OUTPUT_ROOT/dids/$DATASET_ID/threads-$THREADS

if [[ $DRY_RUN == false ]]; then
    [[ -x $BINARY ]] || die "benchmark binary is missing or not executable: $BINARY (run build_dids.sh)"
    if [[ $MODE != query && ! -f $BASE_PATH ]]; then
        printf 'SKIP %s: base file is missing: %s\n' "$DATASET_ID" "$BASE_PATH" >&2
        exit 0
    fi
    if [[ $MODE != build && ! -f $QUERY_PATH ]]; then
        printf 'SKIP %s: query file is missing: %s\n' "$DATASET_ID" "$QUERY_PATH" >&2
        exit 0
    fi
    if [[ -f $OUTPUT_DIR/manifest.json && $FORCE == false ]]; then
        printf 'SKIP %s: results already exist at %s (use --force to replace them)\n' "$DATASET_ID" "$OUTPUT_DIR" >&2
        exit 0
    fi
    mkdir -p -- "$INDEX_DIR" "$OUTPUT_DIR"
fi

command=("$BINARY" --mode "$MODE" --dataset-id "$DATASET_ID" --dimension "$TS_SIZE"
    --base-file "$BASE_PATH" --base-count "$DATASET_SIZE"
    --query-file "$QUERY_PATH" --query-count "$QUERY_COUNT"
    --scalar-type "$SCALAR_TYPE" --base-header "$BASE_HEADER" --query-header "$QUERY_HEADER"
    --preprocessing "$PREPROCESSING" --threads "$THREADS" --search "$SEARCH" --k "$K"
    --approximate-nodes "$APPROXIMATE_NODES" --ref-objects "$REF_OBJECTS"
    --leaf-size "$LEAF_SIZE" --read-buffer "$READ_BUFFER" --write-buffer "$WRITE_BUFFER"
    --index-dir "$INDEX_DIR" --output-dir "$OUTPUT_DIR")

prefix=(env OMP_NUM_THREADS="$THREADS" OMP_PROC_BIND=close OMP_PLACES=cores)
NUMACTL_BIN=$(command -v numactl 2>/dev/null || true)
if [[ $NUMA_MODE != none && -n $NUMACTL_BIN ]]; then
    if [[ $NUMA_MODE == auto ]]; then
        prefix+=(numactl --interleave=all)
    else
        nodes=$(seq -s, 0 $((NUMA_MODE - 1)))
        prefix+=(numactl --interleave="$nodes")
    fi
fi

if [[ $DRY_RUN == true ]]; then
    print_command "${prefix[@]}" "${command[@]}"
    exit 0
fi

{
    printf 'command: '
    print_command "${prefix[@]}" "${command[@]}"
    printf 'date_utc: %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf 'host: %s\n' "$(hostname)"
    uname -a
    command -v lscpu >/dev/null 2>&1 && lscpu || true
    "$BINARY" --help | head -1
} > "$OUTPUT_DIR/environment.txt"

set +e
printf 'Starting DIDS dataset=%s threads=%s mode=%s\n' "$DATASET_ID" "$THREADS" "$MODE"
printf 'Index:   %s\n' "$INDEX_DIR"
[[ $TEMPORARY_INDEX == true ]] && printf 'Index cleanup: scheduled at exit\n'
printf 'Results: %s\n' "$OUTPUT_DIR"
"${prefix[@]}" "${command[@]}" 2>&1 | tee "$OUTPUT_DIR/run.log"
status=${PIPESTATUS[0]}
set -e
if [[ $status -eq 0 && $MODE != build ]]; then
    print_benchmark_summary | tee -a "$OUTPUT_DIR/run.log"
fi
exit "$status"
