#!/usr/bin/env python3
"""Tune DIDS SAX/leaf sizes, then replay saved winners on evaluation queries."""
import argparse
import csv
import itertools
import json
import math
from pathlib import Path
import shlex
import subprocess
import tempfile

RUNNER = Path(__file__).resolve().with_name('run_dids.sh')
PARAMETERS = ('ref-objects', 'approximate-nodes', 'read-buffer', 'write-buffer', 'k')


def positive_list(value):
    try:
        values = [int(part) for part in value.split(',')]
        if not values or any(v <= 0 for v in values) or len(set(values)) != len(values):
            raise ValueError
        return values
    except ValueError:
        raise argparse.ArgumentTypeError('expected distinct positive integers separated by commas')


def score(path):
    with path.open(newline='') as stream:
        values = [float(row['query_time_ms']) for row in csv.DictReader(stream)
                  if row['mode'] == 'exact' and int(row['rank']) == 1]
    if not values or any(not math.isfinite(v) or v < 0 for v in values):
        raise ValueError('missing or invalid exact query timings')
    return sum(values) / len(values)


def invoke(dataset, threads, settings, output, extra, dry_run):
    command = ['bash', str(RUNNER), dataset, *extra, '--threads', str(threads),
               '--mode', 'all', '--search', 'exact', '--output-root', str(output)]
    for key, value in settings.items():
        command += ['--' + key, str(value)]
    if dry_run:
        command.append('--dry-run')
    print(shlex.join(command), flush=True)
    if dry_run:
        return subprocess.run(command, check=False).returncode
    Path(output).mkdir(parents=True, exist_ok=True)
    # Keep errors emitted before the shell runner creates its own run.log.
    with (Path(output) / 'grid-runner.log').open('w') as log:
        with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, bufsize=1) as process:
            for line in process.stdout:
                print(line, end='', flush=True)
                log.write(line)
                log.flush()
            return process.wait()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('tune', 'run'))
    parser.add_argument('--config', type=Path, required=True, help='Saved best-config JSON')
    parser.add_argument('--datasets', help='Comma-separated dataset IDs (tune defaults to all active datasets)')
    parser.add_argument('--threads', type=positive_list, help='Thread counts; required for tune')
    parser.add_argument('--sax-lengths', type=positive_list, help='Optional SAX sweep; default: registered length per dataset')
    leaves = parser.add_mutually_exclusive_group()
    leaves.add_argument('--leaf-sizes', type=positive_list)
    leaves.add_argument('--best-leaf-config', type=Path,
                        help='Fix each dataset/thread leaf size to its winner in this saved config')
    parser.add_argument('--output-root', type=Path, help='Evaluation result root; required for run')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--resume', action='store_true', help='Skip successful tuning candidates and retry missing/failed ones')
    # Runner arguments follow -- to keep ownership of options explicit.
    import sys
    args_in = sys.argv[1:]
    split = args_in.index('--') if '--' in args_in else len(args_in)
    args = parser.parse_args(args_in[:split])
    extra = args_in[split + 1:]
    if args.best_leaf_config and args.action != 'tune':
        parser.error('--best-leaf-config is only supported for tune')
    fixed_leaves = None
    if args.best_leaf_config:
        leaf_config = json.loads(args.best_leaf_config.read_text())
        if leaf_config.get('version') != 1:
            parser.error('unsupported best-leaf config version')
        fixed_leaves = {(e['dataset'], e['threads']): int(e['parameters']['leaf-size'])
                        for e in leaf_config['best']}
        if not fixed_leaves or any(v <= 0 for v in fixed_leaves.values()):
            parser.error('best-leaf config has no valid leaf sizes')
    reserved = {'--threads', '--sax-length', '--leaf-size', '--output-root', '--mode',
                '--search', '--binary', '--dry-run'}
    if args.action == 'run':
        reserved.update('--' + key for key in PARAMETERS)
    if any(arg.split('=')[0] in reserved for arg in extra):
        parser.error('runner arguments override a grid/config-controlled option')
    datasets = args.datasets.split(',') if args.datasets else None
    if datasets and any(not d or '/' in d or d in ('.', '..') for d in datasets):
        parser.error('invalid dataset list')
    if args.action == 'run':
        if args.output_root is None:
            parser.error('run requires --output-root')
        config = json.loads(args.config.read_text())
        if config.get('version') != 1:
            parser.error('unsupported config version')
        entries = [e for e in config['best'] if
                   (datasets is None or e['dataset'] in datasets) and
                   (args.threads is None or e['threads'] in args.threads)]
        if not entries:
            parser.error('no matching saved configurations')
        if datasets and set(datasets) - {e['dataset'] for e in entries}:
            parser.error('a requested dataset has no saved configuration')
        if args.threads and set(args.threads) - {e['threads'] for e in entries}:
            parser.error('a requested thread count has no saved configuration')
        failures = 0
        for entry in entries:
            failures += bool(invoke(entry['dataset'], entry['threads'], entry['parameters'],
                                    args.output_root, extra, args.dry_run))
        return int(bool(failures))
    if not args.threads:
        parser.error('tune requires --threads')
    if datasets is None or datasets == ['all']:
        registry = RUNNER.parent / 'lib' / 'datasets.sh'
        datasets = subprocess.check_output(
            ['bash', '-c', 'source "$1"; active_datasets', 'dids-grid', str(registry)],
            text=True,
        ).split()
        if not datasets:
            parser.error('dataset registry returned no active datasets')
    scores_path = args.config.with_suffix('.scores.csv')
    if not args.resume and (args.config.exists() or scores_path.exists()):
        parser.error('config or scores already exist; use --resume or a new --config path')
    config = (json.loads(args.config.read_text()) if args.resume and args.config.exists()
              else {'version': 1, 'objective': 'mean exact rank-1 query_time_ms', 'best': []})
    if config.get('version') != 1:
        parser.error('unsupported config version')
    previous = []
    if args.resume and scores_path.exists():
        with scores_path.open(newline='') as stream:
            previous = list(csv.DictReader(stream))
    successful = set()
    for row in previous:
        if row['status'] == 'ok':
            mean = float(row['mean_query_time_ms'])
            if not math.isfinite(mean) or mean < 0:
                parser.error('invalid successful score in existing CSV')
            successful.add((row['dataset'], int(row['threads']),
                            int(row['sax_length']), int(row['leaf_size'])))
    winners = {(e['dataset'], e['threads']): e for e in config['best']}
    if any((d, t) not in winners for d, t, s, l in successful):
        parser.error('successful scores lack saved best configurations; restore the matching JSON')
    if not args.dry_run:
        args.config.parent.mkdir(parents=True, exist_ok=True)
    artifacts = args.config.with_suffix('.runs')
    failures = 0
    if fixed_leaves is not None and not any(
            (d, t) in fixed_leaves for d, t in itertools.product(datasets, args.threads)):
        parser.error('no saved leaf sizes match the requested datasets/threads')
    for dataset, threads in itertools.product(datasets, args.threads):
        if fixed_leaves is not None:
            if (dataset, threads) not in fixed_leaves:
                print(f'SKIP {dataset} threads={threads}: no winner in {args.best_leaf_config}', flush=True)
                continue
            leaf_items = [fixed_leaves[(dataset, threads)]]
        else:
            leaf_items = args.leaf_sizes or [5000, 10000, 20000]
        best = winners.get((dataset, threads))
        if args.sax_lengths:
            sax_items = args.sax_lengths
        else:
            registry = RUNNER.parent / 'lib' / 'datasets.sh'
            registered = subprocess.check_output(
                ['bash', '-c', 'set -eu; source "$1"; load_dataset "$2" standard; printf "%s" "$DIDS_SAX_LENGTH"',
                 'dids-grid', str(registry), dataset], text=True)
            sax_items = [int(registered)]
        for sax, leaf in itertools.product(sax_items, leaf_items):
            if (dataset, threads, sax, leaf) in successful:
                print(f'SKIP successful: {dataset} threads={threads} sax={sax} leaf={leaf}', flush=True)
                continue
            settings = {'leaf-size': leaf, 'sax-length': sax}
            candidate_parent = artifacts / dataset / f'threads-{threads}' / f'sax-{sax}-leaf-{leaf}'
            if args.dry_run:
                candidate = candidate_parent / 'DRY-RUN'
            else:
                candidate_parent.mkdir(parents=True, exist_ok=True)
                candidate = Path(tempfile.mkdtemp(prefix='attempt-', dir=candidate_parent))
            status = invoke(dataset, threads, settings, candidate, extra, args.dry_run)
            if args.dry_run:
                failures += bool(status)
                continue
            mean = None
            try:
                if status:
                    raise ValueError(f'runner exited {status}')
                manifests = list(candidate.glob('dids/*/threads-*/manifest.json'))
                if len(manifests) != 1:
                    raise ValueError('runner skipped dataset or produced no manifest')
                manifest = json.loads(manifests[0].read_text())
                settings['sax-length'] = int(manifest['sax_length'])
                mean = score(manifests[0].with_name('queries.csv'))
                command = manifest['command']
                for key in PARAMETERS:
                    settings[key] = int(command[command.index('--' + key) + 1])
                if best is None or mean < best['mean_query_time_ms']:
                    best = {'dataset': dataset, 'threads': threads,
                            'parameters': settings, 'mean_query_time_ms': mean,
                            'result_directory': str(manifests[0].parent.resolve()),
                            'tuning_workload': {k: manifest[k] for k in
                                ('base_file', 'base_count', 'query_file', 'query_count', 'dimension')}}
                result = 'ok'
            except (ValueError, KeyError, OSError) as error:
                result = str(error)
                failures += 1
            # Checkpoint after every candidate, preserving winners for other datasets.
            if best:
                winners[(dataset, threads)] = best
            config['best'] = list(winners.values())
            pending = args.config.with_suffix('.tmp')
            pending.write_text(json.dumps(config, indent=2) + '\n')
            pending.replace(args.config)
            new_file = not scores_path.exists()
            with scores_path.open('a', newline='') as stream:
                writer = csv.writer(stream)
                if new_file:
                    writer.writerow(('dataset', 'threads', 'sax_length', 'leaf_size', 'mean_query_time_ms', 'status'))
                writer.writerow((dataset, threads, sax, leaf, mean, result))
            if result == 'ok':
                successful.add((dataset, threads, sax, leaf))
            print(f'{dataset} SAX {sax} leaf {leaf}: {result}; logs: {candidate}', flush=True)
        if best:
            print('Selected:', json.dumps(best), flush=True)
    return int(bool(failures))


if __name__ == '__main__':
    raise SystemExit(main())
