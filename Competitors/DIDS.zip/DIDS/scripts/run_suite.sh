#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
# shellcheck source=lib/datasets.sh
source "$SCRIPT_DIR/lib/datasets.sh"

usage() {
    cat <<'USAGE'
Usage: run_suite.sh standard --threads LIST --index-type dids [OPTIONS]

Runs the DIDS dataset/thread matrix using the common benchmark interface.

Required options:
  --threads LIST          Comma-separated thread counts, for example 1,32,64
  --index-type dids       Select the DIDS competitor

Common options:
  --datasets LIST         Limit the active dataset list
  --sax-lengths LIST      Benchmark each SAX length and publish the fastest run
  --data-root PATH        Main dataset root
  --query-root PATH       Main query root
  --seisbench-root PATH   SeisBench dataset root
  --index-root PATH       Persistent DIDS index root
  --output-root PATH      Structured benchmark result root
  --query-count N         Queries per dataset
  --k N                   Neighbors per query
  --ref-objects N         DIDS reference objects (must be >= threads)
  --force                 Replace existing result files
  --dry-run               Print resolved commands only

The standard suite runs exact DIDS search. Remaining DIDS
options are forwarded to each `run_dids.sh` invocation; see
`scripts/run_dids.sh --help`.

SAX tuning selects the lowest mean exact query_time_ms over the requested
queries. Candidate outputs are isolated from the normal runtime-log tree; only
the selected candidate is published there, along with sax-tuning.csv.
USAGE
}

die() { printf 'Error: %s\n' "$*" >&2; exit 2; }
is_positive_integer() { [[ $1 =~ ^[1-9][0-9]*$ ]]; }

cleanup_tuning_root() {
    local status=$?
    trap - EXIT
    if [[ -n ${TUNING_ROOT:-} && -d $TUNING_ROOT && $TUNING_ROOT == /tmp/dids-sax-tuning.* ]]; then
        rm -rf -- "$TUNING_ROOT" || printf 'Warning: could not remove SAX tuning directory: %s\n' "$TUNING_ROOT" >&2
    fi
    exit "$status"
}

mean_exact_query_ms() {
    local csv=$1
    awk -F, '
        $1 == "query_id" { next }
        $2 == "exact" && $3 == 1 { count++; total += $6 }
        END {
            if (!count) exit 1
            printf "%.9f\n", total / count
        }
    ' "$csv"
}

[[ $# -ge 1 ]] || { usage >&2; exit 2; }
if [[ $1 == -h || $1 == --help ]]; then
    usage
    exit 0
fi

SUITE=$1
shift
[[ $SUITE == standard ]] || die "DIDS currently supports the 'standard' suite"

THREADS=
INDEX_TYPE=
DATASETS=
SAX_LENGTHS=
SAX_LENGTH_OVERRIDE_SEEN=false
BINARY_SEEN=false
OUTPUT_ROOT=${DIDS_RESULTS_ROOT:-"$HOME/dids_results"}
FORCE=false
DRY_RUN=false
forward=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --threads) [[ $# -ge 2 ]] || die "$1 requires a value"; THREADS=$2; shift 2 ;;
        --index-type) [[ $# -ge 2 ]] || die "$1 requires a value"; INDEX_TYPE=$2; shift 2 ;;
        --datasets) [[ $# -ge 2 ]] || die "$1 requires a value"; DATASETS=$2; shift 2 ;;
        --sax-lengths) [[ $# -ge 2 ]] || die "$1 requires a value"; SAX_LENGTHS=$2; shift 2 ;;
        --sax-length) [[ $# -ge 2 ]] || die "$1 requires a value"; SAX_LENGTH_OVERRIDE_SEEN=true; forward+=("$1" "$2"); shift 2 ;;
        --binary) [[ $# -ge 2 ]] || die "$1 requires a value"; BINARY_SEEN=true; forward+=("$1" "$2"); shift 2 ;;
        --output-root) [[ $# -ge 2 ]] || die "$1 requires a value"; OUTPUT_ROOT=$2; shift 2 ;;
        --force) FORCE=true; shift ;;
        --dry-run) DRY_RUN=true; shift ;;
        *) forward+=("$1"); shift ;;
    esac
done

[[ -n $THREADS ]] || die '--threads is required'
[[ $INDEX_TYPE == dids ]] || die '--index-type must be dids'
[[ -z $SAX_LENGTHS || $SAX_LENGTH_OVERRIDE_SEEN == false ]] || die '--sax-lengths cannot be combined with --sax-length'
[[ -z $SAX_LENGTHS || $BINARY_SEEN == false ]] || die '--sax-lengths cannot be combined with --binary'

if [[ -z $DATASETS ]]; then
    mapfile -t dataset_items < <(active_datasets)
else
    IFS=',' read -r -a dataset_items <<< "$DATASETS"
fi
IFS=',' read -r -a thread_items <<< "$THREADS"
for threads in "${thread_items[@]}"; do
    is_positive_integer "$threads" || die "invalid thread count '$threads'"
done

sax_items=()
if [[ -n $SAX_LENGTHS ]]; then
    IFS=',' read -r -a requested_sax_items <<< "$SAX_LENGTHS"
    for sax_length in "${requested_sax_items[@]}"; do
        is_positive_integer "$sax_length" || die "invalid SAX length '$sax_length'"
        for existing_sax in "${sax_items[@]}"; do
            [[ $existing_sax != "$sax_length" ]] || die "duplicate SAX length '$sax_length'"
        done
        sax_items+=("$sax_length")
    done
    if [[ $DRY_RUN == true ]]; then
        TUNING_ROOT=/tmp/dids-sax-tuning.DRY-RUN
    else
        TUNING_ROOT=$(mktemp -d /tmp/dids-sax-tuning.XXXXXX) || die 'could not create a SAX tuning directory under /tmp'
        trap cleanup_tuning_root EXIT
    fi
fi

failures=0
for dataset in "${dataset_items[@]}"; do
    load_dataset "$dataset" standard || {
        failures=$((failures + 1))
        continue
    }
    canonical_dataset_id=$DATASET_ID
    for threads in "${thread_items[@]}"; do
        printf '\n=== DIDS dataset=%s threads=%s ===\n' "$dataset" "$threads"
        common_args=("$dataset" --threads "$threads" "${forward[@]}" --mode all --search exact)
        [[ $FORCE == false ]] || common_args+=(--force)
        [[ $DRY_RUN == false ]] || common_args+=(--dry-run)

        if [[ -z $SAX_LENGTHS ]]; then
            if ! "$SCRIPT_DIR/run_dids.sh" "${common_args[@]}" --output-root "$OUTPUT_ROOT"; then
                printf 'FAILED dataset=%s threads=%s\n' "$dataset" "$threads" >&2
                failures=$((failures + 1))
            fi
            continue
        fi

        canonical_dir=$OUTPUT_ROOT/dids/$canonical_dataset_id/threads-$threads
        if [[ $DRY_RUN == false && -f $canonical_dir/manifest.json && $FORCE == false ]]; then
            printf 'SKIP %s: results already exist at %s (use --force to replace them)\n' \
                "$canonical_dataset_id" "$canonical_dir" >&2
            continue
        fi

        scores_file=$TUNING_ROOT/scores-${canonical_dataset_id}-threads-${threads}.csv
        if [[ $DRY_RUN == false ]]; then
            printf 'sax_length,mean_query_time_ms,status\n' > "$scores_file"
        fi
        best_sax=
        best_mean_ms=
        best_dir=

        for sax_length in "${sax_items[@]}"; do
            candidate_root=$TUNING_ROOT/sax-$sax_length
            printf '%s\n' "--- SAX candidate: $sax_length ---"
            if ! "$SCRIPT_DIR/run_dids.sh" "${common_args[@]}" \
                --sax-length "$sax_length" --output-root "$candidate_root"; then
                printf 'FAILED dataset=%s threads=%s sax=%s\n' "$dataset" "$threads" "$sax_length" >&2
                [[ $DRY_RUN == true ]] || printf '%s,,failed\n' "$sax_length" >> "$scores_file"
                failures=$((failures + 1))
                continue
            fi
            [[ $DRY_RUN == false ]] || continue

            candidate_dir=$candidate_root/dids/$canonical_dataset_id/threads-$threads
            if [[ ! -f $candidate_dir/queries.csv ]]; then
                printf 'SKIP candidate without query results: dataset=%s threads=%s sax=%s\n' \
                    "$dataset" "$threads" "$sax_length" >&2
                printf '%s,,skipped\n' "$sax_length" >> "$scores_file"
                continue
            fi
            if ! mean_ms=$(mean_exact_query_ms "$candidate_dir/queries.csv"); then
                printf 'FAILED to score dataset=%s threads=%s sax=%s\n' "$dataset" "$threads" "$sax_length" >&2
                printf '%s,,invalid\n' "$sax_length" >> "$scores_file"
                failures=$((failures + 1))
                continue
            fi
            printf '%s,%s,ok\n' "$sax_length" "$mean_ms" >> "$scores_file"
            printf 'SAX %s mean exact query time: %.3f ms\n' "$sax_length" "$mean_ms"
            if [[ -z $best_mean_ms ]] || awk -v candidate="$mean_ms" -v best="$best_mean_ms" \
                'BEGIN { exit !(candidate < best) }'; then
                best_sax=$sax_length
                best_mean_ms=$mean_ms
                best_dir=$candidate_dir
            fi
        done

        if [[ $DRY_RUN == true ]]; then
            printf 'Dry run only: the lowest mean exact query time would be published to %s\n' "$canonical_dir"
            continue
        fi
        if [[ -z $best_sax ]]; then
            printf 'No successful SAX candidate for dataset=%s threads=%s\n' "$dataset" "$threads" >&2
            continue
        fi

        mkdir -p -- "$canonical_dir"
        cp -a -- "$best_dir/." "$canonical_dir/"
        awk -F, -v best="$best_sax" '
            BEGIN { OFS=","; print "sax_length", "mean_query_time_ms", "status", "selected" }
            NR > 1 { print $1, $2, $3, ($1 == best ? "true" : "false") }
        ' "$scores_file" > "$canonical_dir/sax-tuning.csv"
        printf 'Selected SAX %s for dataset=%s threads=%s (mean %.3f ms); published %s\n' \
            "$best_sax" "$canonical_dataset_id" "$threads" "$best_mean_ms" "$canonical_dir"
    done
done
(( failures == 0 )) || { printf '%s benchmark run(s) failed\n' "$failures" >&2; exit 1; }
