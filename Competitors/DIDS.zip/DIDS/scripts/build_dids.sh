#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
REPO_ROOT=$(cd -- "$SCRIPT_DIR/.." && pwd -P)

usage() {
    cat <<'USAGE'
Usage: build_dids.sh [--dimensions LIST | --variants LIST]
                     [--build-root PATH] [--bin-dir PATH]
                     [--jobs N] [--cmake PATH] [--clean]

Builds the registered DIDS (dimension, SAX length) executable variants. LIST is
a comma-separated subset of: 96,100,128,200,256. Dimension 100 builds SAX 20
and 34; dimension 128 builds SAX 16 and 32. The remaining registered pairs are
(96,32), (200,20), and (256,16). To build arbitrary tuning candidates, pass
--variants as comma-separated DIMENSION:SAX pairs, for example
--variants 96:16,96:24,96:32. By default, the build uses every available logical
CPU. Use --jobs N to set an explicit limit.
USAGE
}

die() { printf 'Error: %s\n' "$*" >&2; exit 2; }

DIMENSIONS=96,100,128,200,256
DIMENSIONS_REQUESTED=false
VARIANTS=
BUILD_ROOT=$REPO_ROOT/build/benchmark
BIN_DIR=$REPO_ROOT/bin
JOBS=${DIDS_BUILD_JOBS:-}
CMAKE_BIN=${CMAKE:-cmake}
CLEAN=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --dimensions) [[ $# -ge 2 ]] || die "$1 requires a value"; DIMENSIONS=$2; DIMENSIONS_REQUESTED=true; shift 2 ;;
        --variants) [[ $# -ge 2 ]] || die "$1 requires a value"; VARIANTS=$2; shift 2 ;;
        --build-root) [[ $# -ge 2 ]] || die "$1 requires a value"; BUILD_ROOT=$2; shift 2 ;;
        --bin-dir) [[ $# -ge 2 ]] || die "$1 requires a value"; BIN_DIR=$2; shift 2 ;;
        --jobs) [[ $# -ge 2 ]] || die "$1 requires a value"; JOBS=$2; shift 2 ;;
        --cmake) [[ $# -ge 2 ]] || die "$1 requires a value"; CMAKE_BIN=$2; shift 2 ;;
        --clean) CLEAN=true; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown option '$1'" ;;
    esac
done

[[ -z $VARIANTS || $DIMENSIONS_REQUESTED == false ]] || die '--variants cannot be combined with --dimensions'

command -v "$CMAKE_BIN" >/dev/null 2>&1 || die "CMake was not found: $CMAKE_BIN"
if [[ -z $JOBS ]]; then
    if command -v nproc >/dev/null 2>&1; then
        JOBS=$(nproc)
    elif command -v getconf >/dev/null 2>&1; then
        JOBS=$(getconf _NPROCESSORS_ONLN)
    elif command -v sysctl >/dev/null 2>&1; then
        JOBS=$(sysctl -n hw.logicalcpu)
    else
        JOBS=1
    fi
fi
[[ $JOBS =~ ^[1-9][0-9]*$ ]] || die '--jobs and DIDS_BUILD_JOBS must be a positive integer'
[[ $(uname -m) == x86_64 ]] || die 'DIDS currently requires an x86_64 CPU with AVX2'
printf 'Building with %s parallel job(s)\n' "$JOBS"

mkdir -p -- "$BUILD_ROOT" "$BIN_DIR"
pairs=()
if [[ -n $VARIANTS ]]; then
    IFS=',' read -r -a requested_pairs <<< "$VARIANTS"
    for pair in "${requested_pairs[@]}"; do
        [[ $pair =~ ^([1-9][0-9]*):([1-9][0-9]*)$ ]] || die "invalid variant '$pair' (expected DIMENSION:SAX)"
        dimension=${BASH_REMATCH[1]}
        sax_length=${BASH_REMATCH[2]}
        (( sax_length <= dimension )) || die "SAX length $sax_length exceeds dimension $dimension"
        pairs+=("$dimension:$sax_length")
    done
else
    IFS=',' read -r -a dimension_list <<< "$DIMENSIONS"
    for dimension in "${dimension_list[@]}"; do
        case "$dimension" in
            96) sax_lengths=(32) ;;
            100) sax_lengths=(20 34) ;;
            128) sax_lengths=(16 32) ;;
            200) sax_lengths=(20) ;;
            256) sax_lengths=(16) ;;
            *) die "unsupported dimension '$dimension'" ;;
        esac
        for sax_length in "${sax_lengths[@]}"; do
            pairs+=("$dimension:$sax_length")
        done
    done
fi

for pair in "${pairs[@]}"; do
    dimension=${pair%%:*}
    sax_length=${pair##*:}
    build_dir=$BUILD_ROOT/dim-$dimension-sax-$sax_length
    if [[ $CLEAN == true && -d $build_dir ]]; then
        rm -rf -- "$build_dir"
    fi
    "$CMAKE_BIN" -S "$REPO_ROOT" -B "$build_dir" \
        -DCMAKE_BUILD_TYPE=Release \
        -DDIDS_TS_LENGTH="$dimension" \
        -DDIDS_SAX_LENGTH="$sax_length" \
        -DDIDS_BUILD_EXAMPLE=OFF
    build_args=(--build "$build_dir" --target dids_benchmark --parallel "$JOBS")
    "$CMAKE_BIN" "${build_args[@]}"
    binary=$BIN_DIR/dids_benchmark_${dimension}_sax${sax_length}
    "$CMAKE_BIN" -E copy "$build_dir/dids_benchmark" "$binary"
    printf 'Built %s\n' "$binary"
done
