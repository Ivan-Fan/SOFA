# DIDS benchmark runner

These are the infrastructure adapters for running DIDS against the datasets
registered in `lib/datasets.sh`. They intentionally do not use the MESSI
method/profile flags: DIDS exposes one disk index with exact and approximate
query modes.

## Build on the benchmark host

Requirements:

- Linux x86-64 CPU with AVX2
- GCC 9.4 or newer
- CMake 3.16 or newer
- OpenMP and pthreads
- TCMalloc is optional (used automatically when found)

From the DIDS repository root:

```bash
scripts/build_dids.sh
```

DIDS fixes both the time-series and SAX lengths in C++ templates. The build
script therefore creates binaries named
`bin/dids_benchmark_<dimension>_sax<SAX-length>`. Build a subset if only some
datasets are needed:

```bash
scripts/build_dids.sh --dimensions 128,256 --jobs 16
```

SAX tuning requires one compiled executable for every candidate. Arbitrary
dimension/SAX pairs can be built with `--variants`:

```bash
scripts/build_dids.sh \
  --variants 96:16,96:24,96:32,128:16,128:24,128:32 \
  --jobs 16
```

The original GSL-based random example is disabled by default. The benchmark
binary itself does not need GSL, and TCMalloc is no longer an unconditional
link dependency. The build uses all detected logical CPUs by default; pass
`--jobs N` or set `DIDS_BUILD_JOBS=N` to limit parallelism.

The compiled `(dimension, SAX length)` variants are `(96,32)`, `(100,20)`,
`(100,34)`, `(128,16)`, `(128,32)`, `(200,20)`, and `(256,16)`. The paper
settings are SIFT `(128,32)`, SALD `(128,16)`, SPACEV `(100,34)`, and DEEP
`(96,32)`. Persistent index paths include both values, preventing indexes with
incompatible SAX layouts from being reused.

The released DIDS implementation uses an integer segment width
`dimension / SAX-length`. Consequently, the paper's SPACEV `(100,34)` setting
summarizes 34 two-value segments and leaves the trailing coordinates out of the
SAX lower bound. Exact distance calculations still use all 100 coordinates.
This adapter preserves that artifact for paper-compatible runs.

## Run one dataset

```bash
scripts/run_dids.sh astro \
  --threads 36 \
  --data-root /vol/tmp/schaefpa/messi_datasets \
  --index-root /vol/tmp/schaefpa/dids_indexes \
  --output-root /vol/tmp/schaefpa/competitor_results
```

Useful validation run before a full build:

```bash
scripts/run_dids.sh sald \
  --threads 4 --base-count 20000 --query-count 10 \
  --ref-objects 100 --leaf-size 500 --approximate-nodes 10 \
  --temporary-index \
  --output-root /tmp/dids-results
```

Unless `--index-root` or `DIDS_INDEX_ROOT` is supplied, a one-shot `--mode all`
run creates an isolated `/tmp/dids-index.*` directory and removes it when the
runner exits. This keeps the large DIDS files off the home disk, but the index
cannot be reused for a later `--mode query` run. Use `--index-root` (or
`DIDS_INDEX_ROOT`) when an index should persist. `--temporary-index` explicitly
selects the disposable behavior.

The base count must be at least `100 * ref-objects`, because upstream DIDS
selects its clustering sample at a fixed 1-in-100 interval. The reference-object
count must also be at least the requested thread count.

The default remains 10,000 reference objects for the 100M-row paper workloads.
When that would exceed a smaller dataset's 1% clustering sample, the runner
automatically uses `floor(sqrt(base-count))`, following the paper's parameter
guideline (and raises it to the thread count when necessary). An explicit
`--ref-objects` value is never adjusted; invalid explicit values fail with the
sample limit in the error message.

For the paper's 100M-row datasets, the defaults follow its approximately
79M--100M configuration:

| DIDS parameter | Runner option | Default |
| --- | --- | ---: |
| Reference objects (`n_r`) | `--ref-objects` | 10000 |
| Binary-tree leaf threshold (`th`) | `--leaf-size` | 2000 |
| Graph nodes searched (`n_g`) | `--approximate-nodes` | 200 |
| Grouping read buffer | `--read-buffer` | 100000 |

These defaults are not appropriate for small prefix tests; override them as in
the validation command above. The standard query default remains `k=1` for the
current evaluation workload.

Use `--mode build` and `--mode query` to separate construction from querying.
Query-only runs reuse the index below `DIDS_INDEX_ROOT`. Use `--search exact`,
`--search approximate`, or the default `--search both`; the latter records
recall@K against DIDS exact search.
Pass `--sax-length N` to override a dataset's registered SAX length for one
run. The corresponding `dids_benchmark_<dimension>_sax<N>` binary must already
exist.

## Run a suite

```bash
scripts/run_suite.sh standard \
  --datasets astro,sald,sift1b \
  --threads 1,16,36 \
  --index-type dids \
  --data-root /vol/tmp/schaefpa/messi_datasets \
  --index-root /vol/tmp/schaefpa/dids_indexes \
  --output-root /vol/tmp/schaefpa/competitor_results
```

`run_suite.sh` invokes `run_dids.sh` directly for every dataset/thread pair
with exact search. Pass `--threads 1,32,64` to run a scaling matrix. Run
`run_dids.sh --help` for format, header, normalization, DIDS tuning, NUMA, and
path overrides.

To select a SAX length empirically, pass a comma-separated candidate list:

```bash
scripts/run_suite.sh standard \
  --datasets sald,sift1b,deep1b \
  --threads 64 \
  --index-type dids \
  --sax-lengths 16,24,32 \
  --index-root /vol/tmp/schaefpa/dids_indexes \
  --output-root /vol/tmp/schaefpa/competitor_results \
  --force
```

Each candidate builds its own SAX-specific index and runs the complete exact
query workload. Selection uses the lowest mean `query_time_ms` among exact
rank-1 rows. Candidate result files live in an isolated temporary directory,
so notebook log discovery cannot mix candidates. Only the winning candidate is
copied to the normal `dids/<dataset>/threads-<N>/` result directory. A
`sax-tuning.csv` file records every candidate's mean, status, and selected flag.
The winning SAX value also remains in `manifest.json`.

Selecting and reporting on the same queries gives an optimistically biased
runtime. For a publication-quality comparison, tune SAX on a separate query
set, then run the selected value once on the held-out evaluation queries.

By default, the standard suite includes the main active datasets and all
registered SeisBench datasets. Set `DIDS_SEISBENCH_ROOT` (or pass
`--seisbench-root`) to point at the SeisBench files; missing files are skipped.
Seismic, SimSearchNet, Text-to-Image, and TuringANNS are opt-in and must be
selected explicitly with `--datasets`.
`--dry-run` prints the fully resolved command and does not require datasets or
compiled binaries. Build the dimension-specific binaries first with
`scripts/build_dids.sh`.

## Workload formats and results

The dataset registry explicitly declares scalar type, row dimension, raw/header
format, and preprocessing. The adapter streams `uint8`/`int8` input into
float32 and applies per-row z-normalization where the registry requires it.
Both base and query rows receive the same transform. Header-bearing inputs can
be selected with `--base-header u32-count-dim` and
`--query-header u32-count-dim`; their `(uint32 count, uint32 dimension)` values
are validated before use.

Results follow this layout:

```text
<output-root>/dids/<dataset>/threads-<N>/
  manifest.json
  build.csv
  queries.csv
  environment.txt
  run.log
  sax-tuning.csv        # present when --sax-lengths selected the run
```

Distances are squared L2. `index_position` is the position in DIDS's reordered
on-disk data file, not the original source row ID; upstream DIDS does not retain
that mapping. Existing result manifests are protected unless `--force` is
given. Missing base/query files skip only that dataset, allowing suites to
continue.

After every successful query run, `run_dids.sh` prints a DIDS benchmark
summary. It reports average SAX scans and exact distance computations per
query (and their percentages of the base set), together with mean wall time per
query. The same counters are stored on every `queries.csv` row; query durations
are recorded in milliseconds in `query_time_ms`.

Index builds print a separate time breakdown for base preparation, reference
selection/k-means, grouping, and B-tree/HNSW construction. The corresponding
seconds are retained in `build.csv` alongside the total index-build time.

Environment variables mirror the runner flags:

| Variable | Purpose |
| --- | --- |
| `DIDS_DATA_ROOT`, `DIDS_QUERY_ROOT` | Main data and query roots |
| `DIDS_SEISBENCH_ROOT`, `DIDS_SEISBENCH_QUERY_ROOT` | SeisBench roots |
| `DIDS_INDEX_ROOT` | Persistent DIDS indexes |
| `DIDS_RESULTS_ROOT` | Structured result tree |

The older `run_*.sh` files under `scripts_bak/` are retained MESSI compatibility
artifacts. The supported DIDS entrypoints are `build_dids.sh`, `run_dids.sh`,
and `run_suite.sh` under `scripts/`.

## SAX × leaf-size grid and reusable best configurations

The existing suite only sweeps explicitly supplied `--sax-lengths`; it does
not sweep leaf sizes. The new Python 3 driver defaults to each dataset's registered SAX length and leaf sizes
`5000,10000,20000` (3 builds/query runs per dataset/thread pair).
Omit `--datasets` to use all active datasets. Add `--sax-lengths 16,24,32`
only if you also want a SAX sweep (9 runs per dataset/thread pair). Reference objects retain the runner's dataset-dependent
default; graph nodes remain 200. Override fixed parameters after `--`.

From the DIDS root, for example for Iquique and LenDB (256 dimensions):

```bash
scripts/build_dids.sh --dimensions 256 --jobs 16
python3 scripts/grid_search.py tune \
  --datasets iquique,lendb --threads 64 \
  --config /vol/tmp/schaefpa/dids_tuning/best.json \
  --leaf-sizes 5000,10000,20000 \
  -- --data-root /vol/tmp/schaefpa/messi_datasets \
  --seisbench-root /vol/tmp/schaefpa/seismic

python3 scripts/grid_search.py run \
  --config /vol/tmp/schaefpa/dids_tuning/best.json \
  --output-root /vol/tmp/schaefpa/competitor_results \
  -- --data-root /vol/tmp/schaefpa/messi_datasets \
  --seisbench-root /vol/tmp/schaefpa/seismic \
  --seisbench-query-root /vol/tmp/schaefpa/seismic_heldout
```

Build all dimension/SAX pairs required by your selected datasets first.
`--dry-run` prints resolved runner commands without running benchmarks.
`--sax-lengths` and `--leaf-sizes` accept other positive integer lists.
Each winner minimizes mean exact rank-1 query time for one dataset/thread pair.
`best.json` stores the winning SAX/leaf sizes, resolved fixed DIDS parameters,
score, and tuning workload paths/counts. `best.scores.csv` preserves all
candidate scores and failures. Use `--resume` with the same config filename to skip successful candidates and
retry failed or missing candidates. Use a new filename when changing the workload
or fixed parameters; resume identifies candidates by dataset, threads, SAX length,
and leaf size. Failures produce a nonzero exit status,
but successful winners are still saved after each dataset/thread pair.
Candidate CSVs/logs are retained under `<config-stem>.runs/`, with a separate
attempt directory for every retry. `grid-runner.log` also captures errors before
the benchmark starts. Old successful runs whose logs were deleted are still
skipped during resume; those deleted logs cannot be recovered. No tuning measurements are published as final
experiment results. The `run` action loads winners and performs fresh exact
build-and-query experiments, optionally filtered by `--datasets`/`--threads`.
Use separate tuning and evaluation query files/roots to avoid selection bias.

Without `--index-root`, each candidate's index is disposable. With an explicit
index root, indexes persist under
`<dataset>/dim-<D>-sax-<S>/ref-<R>-leaf-<L>/`, so different leaf/reference
settings do not overwrite one another. This changes the previous index path;
old indexes at the SAX-only path need rebuilding. Dataset content and
preprocessing must still match when reusing an index root. Persistent grids
can require substantial disk space; the default disposable indexes keep only
one candidate at a time.

### Resume an interrupted or partially failed grid

Add `--resume` to the original `tune` command and keep the same `--config`.
Successful CSV rows are skipped; failed and missing candidates are executed.
The scores CSV is an append-only history, so previous failure rows remain after
a successful retry. Winners are checkpointed after each candidate, preserving
results for datasets outside the requested subset. Keep tuning queries, base
data, and fixed parameters unchanged when resuming. New per-query logs persist
under `<config-stem>.runs/<dataset>/threads-N/sax-S-leaf-L/attempt-*/dids/`.
Indexes remain disposable unless `--index-root` is supplied.

### Second-stage SAX sweep at the previously selected leaf size

Save a snapshot of the completed leaf search, then load its per-dataset/thread
leaf sizes with `--best-leaf-config`:

```bash
cp /path/best.json /path/leaf-winners.json
python3 scripts/grid_search.py tune --resume \
  --config /path/best.json --best-leaf-config /path/leaf-winners.json \
  --threads 64 --sax-lengths 16,24,32 \
  -- --data-root /home/tmp/schaefpa/messi_datasets \
  --seisbench-root /home/tmp/schaefpa/seismic
```

This option is mutually exclusive with `--leaf-sizes`. Only the saved winning
leaf size is tested for each dataset/thread pair. Datasets without a saved
winner are explicitly skipped. Successful matching SAX/leaf candidates are
skipped with `--resume`. The config continues to retain the best result across
both stages, including previously tested SAX values outside the new list.
Build all required dimension/SAX binaries before starting. Keep the snapshot
unchanged for later resumes and keep workload and fixed parameters unchanged.
