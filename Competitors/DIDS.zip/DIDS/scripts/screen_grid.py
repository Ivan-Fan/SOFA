#!/usr/bin/env python3
"""Screen DIDS on dataset prefixes; retain logs and propose scaled finalists."""
import argparse
import itertools
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

from grid_search import RUNNER, PARAMETERS, invoke, score, positive_list


def settings_for(n, threads, ref_factor, leaf_size, graph_fraction, sax):
    refs = max(threads, round(ref_factor * math.sqrt(n)))
    if refs > n // 100:
        raise ValueError(f'{refs} reference points exceed the 1% sample for {n} rows')
    leaf = leaf_size
    nodes = max(1, round(graph_fraction * n / leaf))
    return {'base-count': n, 'ref-objects': refs, 'leaf-size': leaf,
            'approximate-nodes': nodes, 'sax-length': sax}


def save(path, value):
    pending = path.with_suffix('.tmp')
    pending.write_text(json.dumps(value, indent=2) + '\n')
    pending.replace(path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--datasets', help='Comma-separated IDs; default: all active datasets')
    p.add_argument('--threads', type=int, default=64)
    p.add_argument('--screen-count', type=int, default=1000000)
    p.add_argument('--sax-lengths', type=positive_list, default=[16, 24, 32],
                   help='SAX grid (default: 16,24,32)')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--dry-run', action='store_true')
    import sys
    argv = sys.argv[1:]
    split = argv.index('--') if '--' in argv else len(argv)
    args = p.parse_args(argv[:split])
    extra = argv[split+1:]
    allowed = {'--data-root', '--query-root', '--seisbench-root', '--seisbench-query-root',
               '--query-count', '--numa', '--k', '--read-buffer', '--write-buffer'}
    if len(extra) % 2 or any(extra[i] not in allowed for i in range(0, len(extra), 2)):
        p.error('after -- use only input roots, query-count, numa, k, read-buffer, or write-buffer option/value pairs')
    if args.threads <= 0 or args.screen_count <= 0:
        p.error('threads and screen-count must be positive')
    registry = RUNNER.parent / 'lib' / 'datasets.sh'
    datasets = args.datasets.split(',') if args.datasets else subprocess.check_output(
        ['bash', '-c', 'source "$1"; active_datasets', 'screen', str(registry)], text=True).split()
    metadata = {}
    dimensions = set()
    for dataset in datasets:
        output = subprocess.check_output(
            ['bash', '-c', 'set -eu; source "$1"; load_dataset "$2" standard; printf "%s %s %s" "$DATASET_SIZE" "$DIDS_SAX_LENGTH" "$TS_SIZE"',
             'screen', str(registry), dataset], text=True)
        count, registered_sax, dimension = map(int, output.split())
        metadata[dataset] = [count, registered_sax]
        dimensions.add(dimension)
    if not args.dry_run:
        missing = []
        for dimension, sax in itertools.product(sorted(dimensions), args.sax_lengths):
            binary = RUNNER.parent.parent / 'bin' / f'dids_benchmark_{dimension}_sax{sax}'
            if not binary.is_file() or not os.access(binary, os.X_OK):
                missing.append((dimension, sax, binary))
        if missing:
            variants = ','.join(f'{d}:{s}' for d, s, _ in missing)
            p.error('missing/non-executable binaries; no screening runs started:\n' +
                    '\n'.join(str(path) for _, _, path in missing) +
                    f'\nBuild first: bash scripts/build_dids.sh --variants {variants} --jobs 16')
    invocation = {'datasets': metadata, 'threads': args.threads, 'screen_count': args.screen_count,
                  'runner_args': extra, 'ref_factors': [0.5, 1, 2],
                  'sax_lengths': args.sax_lengths, 'leaf_sizes': [20000], 'graph_fractions': [0.02, 0.10, 0.20]}
    state = {'version': 1, 'kind': 'dids-prefix-screening', 'invocation': invocation, 'candidates': {}}
    if args.config.exists():
        if not args.resume:
            p.error('config exists; use --resume or a new path')
        state = json.loads(args.config.read_text())
        if state.get('invocation') != invocation:
            p.error('resume requires the same dataset list, screening size, and runner arguments')
    if not args.dry_run:
        args.config.parent.mkdir(parents=True, exist_ok=True)
    failures = 0
    for dataset, (full_n, registered_sax) in metadata.items():
        n = min(full_n, args.screen_count)
        for rf, lf, gf, sax in itertools.product(invocation['ref_factors'], invocation['leaf_sizes'],
                                               invocation['graph_fractions'], invocation['sax_lengths']):
            key = f'{dataset}/sax-{sax}-ref-{rf}-leaf-{lf}-graph-{gf}'
            if state['candidates'].get(key, {}).get('status') == 'ok':
                print('SKIP successful:', key)
                continue
            parameters = settings_for(n, args.threads, rf, lf, gf, sax)
            parent = args.config.with_suffix('.runs') / key
            if args.dry_run:
                invoke(dataset, args.threads, parameters, parent / 'DRY-RUN', extra, True)
                continue
            parent.mkdir(parents=True, exist_ok=True)
            attempt = Path(tempfile.mkdtemp(prefix='attempt-', dir=parent))
            entry = {'dataset': dataset, 'threads': args.threads, 'parameters': parameters,
                     'ratios': [rf, lf, gf], 'full_count': full_n, 'attempt': str(attempt.resolve())}
            status = invoke(dataset, args.threads, parameters, attempt, extra, False)
            try:
                if status:
                    raise ValueError(f'runner exited {status}')
                manifests = list(attempt.glob('dids/*/threads-*/manifest.json'))
                if len(manifests) != 1:
                    raise ValueError('missing manifest (dataset may have been skipped)')
                manifest = json.loads(manifests[0].read_text())
                entry['mean_query_time_ms'] = score(manifests[0].with_name('queries.csv'))
                entry['result_directory'] = str(manifests[0].parent.resolve())
                command = manifest['command']
                for name in PARAMETERS:
                    parameters[name] = int(command[command.index('--'+name)+1])
                entry['status'] = 'ok'
            except (ValueError, KeyError, OSError) as error:
                entry['status'] = str(error)
                failures += 1
            state['candidates'][key] = entry
            save(args.config, state)
            # These are recommendations, not measured full-data winners.
            finalists = []
            for name in metadata:
                ranked = sorted((e for e in state['candidates'].values()
                                 if e['dataset'] == name and e['status'] == 'ok'),
                                key=lambda e: e['mean_query_time_ms'])[:3]
                for rank, e in enumerate(ranked, 1):
                    full = dict(e['parameters'])
                    full.update(settings_for(e['full_count'], args.threads, *e['ratios'], e['parameters']['sax-length']))
                    finalists.append({'dataset': name, 'rank': rank, 'threads': args.threads,
                                      'screening_mean_ms': e['mean_query_time_ms'],
                                      'full_data_parameters': full})
            save(args.config.with_suffix('.full-candidates.json'),
                 {'kind': 'unvalidated-full-data-candidates', 'candidates': finalists})
            print(key, entry['status'], flush=True)
    return int(bool(failures))


if __name__ == '__main__':
    raise SystemExit(main())
