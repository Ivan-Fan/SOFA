import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('grid', Path(__file__).resolve().parents[1] / 'grid_search.py')
grid = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grid)

class ResumeTests(unittest.TestCase):
    def test_resume_legacy_and_retry(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            config = Path(tmp) / 'best.json'
            original = {'dataset': 'bigann', 'threads': 64, 'parameters': {'sax-length': 32, 'leaf-size': 5000}, 'mean_query_time_ms': 10}
            config.write_text(json.dumps({'version': 1, 'best': [original]}))
            config.with_suffix('.scores.csv').write_text(
                'dataset,threads,sax_length,leaf_size,mean_query_time_ms,status\n'
                'bigann,64,32,5000,10,ok\nbigann,64,registered,10000,,runner exited 2\n')
            argv = ['grid', 'tune', '--resume', '--config', str(config), '--datasets', 'bigann', '--threads', '64']
            with patch.object(sys, 'argv', argv), patch.object(grid, 'invoke', return_value=2) as run:
                self.assertEqual(grid.main(), 1)
                self.assertEqual([c.args[2]['leaf-size'] for c in run.call_args_list], [10000,20000])
            self.assertEqual(json.loads(config.read_text())['best'], [original])
            def success(dataset, threads, settings, output, extra, dry_run):
                directory = Path(output) / 'dids' / dataset / f'threads-{threads}'
                directory.mkdir(parents=True)
                manifest = dict(sax_length=32, base_file='base', base_count=100,
                                query_file='query', query_count=1, dimension=128,
                                command=sum((['--'+k, '1'] for k in grid.PARAMETERS), []))
                (directory/'manifest.json').write_text(json.dumps(manifest))
                (directory/'queries.csv').write_text('mode,rank,query_time_ms\nexact,1,5\n')
                return 0
            with patch.object(sys, 'argv', argv), patch.object(grid, 'invoke', side_effect=success) as run:
                self.assertEqual(grid.main(), 0)
                self.assertEqual(run.call_count, 2)
            winner = json.loads(config.read_text())['best'][0]
            self.assertEqual(winner['mean_query_time_ms'], 5)
            self.assertTrue((Path(winner['result_directory'])/'queries.csv').exists())
            with patch.object(sys, 'argv', argv), patch.object(grid, 'invoke') as run:
                self.assertEqual(grid.main(), 0)
                run.assert_not_called()

    def test_fixed_leaves_sax_sweep(self):
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            config = Path(tmp) / 'best.json'
            snapshot = Path(tmp) / 'leaves.json'
            entries = [dict(dataset=d, threads=64, parameters={'sax-length': s, 'leaf-size': l},
                            mean_query_time_ms=10)
                       for d, s, l in [('bigann',32,5000), ('lendb',16,10000)]]
            text = json.dumps({'version': 1, 'best': entries})
            config.write_text(text)
            snapshot.write_text(text)
            config.with_suffix('.scores.csv').write_text(
                'dataset,threads,sax_length,leaf_size,mean_query_time_ms,status\n'
                'bigann,64,32,5000,10,ok\nlendb,64,16,10000,10,ok\n')
            argv = ['grid', 'tune', '--resume', '--dry-run', '--config', str(config),
                    '--best-leaf-config', str(snapshot), '--datasets', 'bigann,lendb,spacev1b',
                    '--threads', '64', '--sax-lengths', '16,24,32']
            with patch.object(sys, 'argv', argv), patch.object(grid, 'invoke', return_value=0) as run:
                self.assertEqual(grid.main(), 0)
                actual = [(c.args[0], c.args[2]['sax-length'], c.args[2]['leaf-size'])
                          for c in run.call_args_list]
                self.assertEqual(actual, [('bigann',16,5000), ('bigann',24,5000),
                                          ('lendb',24,10000), ('lendb',32,10000)])
            self.assertEqual(config.read_text(), text)
            self.assertEqual(snapshot.read_text(), text)

if __name__ == '__main__':
    unittest.main()
